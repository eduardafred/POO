package model;

import javafx.beans.property.*;

public class Venda {
	private final IntegerProperty id;
	private final StringProperty data_venda;
	private IntegerProperty quantidade;
	private FloatProperty valor_total;
	private IntegerProperty cliente_id;
	private IntegerProperty produto_id;
	
	public Venda() {
		this.id = new SimpleIntegerProperty();
		this.data_venda = new SimpleStringProperty();
		this.quantidade = new SimpleIntegerProperty();
		this.valor_total = new SimpleFloatProperty();
		this.cliente_id = new SimpleIntegerProperty();
		this.produto_id = new SimpleIntegerProperty();

	}
	
	public Venda(String data_venda, int quantidade, float valor_total, int cliente_id, int produto_id) {
		this();
		this.data_venda.set(data_venda);
		this.quantidade.set(quantidade);;
		this.valor_total.set(valor_total);
		this.cliente_id.set(cliente_id);
		this.produto_id.set(produto_id);
	}
	
	public int getId() {return id.get();}
	public String getDataVenda() { return data_venda.get(); }
	public int getQuantidade() { return quantidade.get();	}
	public float getValorTotal() {return valor_total.get(); }
	public int getClienteId() { return cliente_id.get(); }
	public int getProdutoId() { return produto_id.get(); }
	public void setId(int id) {	this.id.set(id); }
	public void setDataVenda(String data_venda) { this.data_venda.set(data_venda);	}
	public void setQuantidade(int quantidade) { this.quantidade.set(quantidade); }
	public void setValorTotal(float valor_total) { this.valor_total.set(valor_total); }
	public void setClienteId(int fk_cliente) { this.cliente_id.set(fk_cliente);	}
	public void setProdutoId(int fk_produto) { this.produto_id.set(fk_produto);	}
	
	
}

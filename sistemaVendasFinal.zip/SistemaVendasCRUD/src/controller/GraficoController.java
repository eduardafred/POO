package controller;

import dao.VendaDAO;
import model.Venda;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import java.net.URL;
import java.sql.SQLException; // Importação necessária para o erro
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class GraficoController implements Initializable {

    @FXML private ComboBox<String> comboPeriodo;
    @FXML private BarChart<String, Number> barChart;
    @FXML private CategoryAxis xAxis;
    @FXML private NumberAxis yAxis;
    
    @FXML private Label lblTotalGeral;
    @FXML private Label lblMediaMensal;
    @FXML private Label lblMelhorMes;

    private VendaDAO vendaDAO;
    private NumberFormat currencyFormat;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        vendaDAO = new VendaDAO();
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

        comboPeriodo.getSelectionModel().selectedItemProperty().addListener(
            (obs, oldVal, newVal) -> handleAtualizar());
            
        handleAtualizar();
    }

    @FXML
    private void handleAtualizar() {
        String periodoSelecionado = comboPeriodo.getSelectionModel().getSelectedItem();
        if (periodoSelecionado == null) return;

        try {
            LocalDate dataCorte = calcularDataCorte(periodoSelecionado);
            List<Venda> todasVendas = vendaDAO.read(); 
            
            Map<String, Double> vendasPorMes = processarVendas(todasVendas, dataCorte);
            
            atualizarGrafico(vendasPorMes);
            atualizarEstatistiscas(vendasPorMes);
            // ------------------------
            
        } catch (Exception e) {
            e.printStackTrace(); 
        }
    }

    private LocalDate calcularDataCorte(String periodo) {
        LocalDate hoje = LocalDate.now();
        if ("Últimos 6 meses".equals(periodo)) {
            return hoje.minusMonths(6);
        } else if ("Últimos 12 meses".equals(periodo)) {
            return hoje.minusMonths(12);
        } else {
            return LocalDate.MIN; 
        }
    }

    private Map<String, Double> processarVendas(List<Venda> vendas, LocalDate dataCorte) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");
        Map<String, Double> agrupado = new HashMap<>();

        for (Venda v : vendas) {
            if (v.getDataVenda().isAfter(dataCorte) || v.getDataVenda().isEqual(dataCorte)) {
                String mesAno = v.getDataVenda().format(formatter);
                agrupado.put(mesAno, agrupado.getOrDefault(mesAno, 0.0) + v.getValorTotal());
            }
        }
        return agrupado;
    }

    private void atualizarGrafico(Map<String, Double> dados) {
        barChart.getData().clear();
        barChart.layout(); 

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Faturamento Mensal");

        List<String> chavesOrdenadas = new ArrayList<>(dados.keySet());
        Collections.sort(chavesOrdenadas, (s1, s2) -> {
            String[] parts1 = s1.split("/");
            String[] parts2 = s2.split("/");
            int res = parts1[1].compareTo(parts2[1]); 
            if (res == 0) return parts1[0].compareTo(parts2[0]); 
            return res;
        });

        for (String mes : chavesOrdenadas) {
            series.getData().add(new XYChart.Data<>(mes, dados.get(mes)));
        }

        barChart.getData().add(series);
    }

    private void atualizarEstatistiscas(Map<String, Double> dados) {
        double total = 0;
        double maiorValor = 0;
        String melhorMes = "--";

        for (Map.Entry<String, Double> entry : dados.entrySet()) {
            double valor = entry.getValue();
            total += valor;

            if (valor > maiorValor) {
                maiorValor = valor;
                melhorMes = entry.getKey();
            }
        }

        double media = dados.isEmpty() ? 0 : total / dados.size();

        lblTotalGeral.setText(currencyFormat.format(total));
        lblMediaMensal.setText(currencyFormat.format(media));
        
        if (!dados.isEmpty()) {
            lblMelhorMes.setText(melhorMes + " (" + currencyFormat.format(maiorValor) + ")");
        } else {
            lblMelhorMes.setText("--");
        }
    }

    private void mostrarAlerta(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}